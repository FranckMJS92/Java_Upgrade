package com.ejemplo.animales;

public class AbstractAnimal {

}
