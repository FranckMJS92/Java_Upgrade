package com.ejemplo.animales;

public class Cat {

}
